/*
. Escribir un programa que pida tu nombre, lo guarde en una variable y lo muestre por 
pantalla
 */
package ejerciciosjava;

import java.util.Scanner;

/**
 *
 * @author User10
 */
public class Ejercicio2 {
    public static void main(String[] args) {
        
    
    Scanner leer = new Scanner(System.in); {
    String nombre;
            System.out.println("ingrese su numbre");
            nombre= leer.nextLine();
            System.out.println("su nombre es: " +nombre);
}
}
}
    
        
